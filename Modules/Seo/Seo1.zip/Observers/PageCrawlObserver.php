<?php

namespace Modules\Seo\Observers;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\UriInterface;
use Spatie\Crawler\CrawlObserver;
use Symfony\Component\DomCrawler\Crawler;

class PageCrawlObserver extends CrawlObserver
{
    private $client;
    /**
     * Class __contruct
     */
    public function __construct()
    {
        set_time_limit(8000000);

        $this->client = new Client([
            'timeout' => 20,
            'verify' => false,
        ]);
    }

    private $pages = [];

    public function willCrawl(UriInterface $uri)
    {
        echo "Now crawling: " . (string) $uri . PHP_EOL;
    }

    /**
     * Called when the crawler has crawled the given url successfully.
     *
     * @param \Psr\Http\Message\UriInterface $url
     * @param \Psr\Http\Message\ResponseInterface $response
     * @param \Psr\Http\Message\UriInterface|null $foundOnUrl
     */
    public function crawled(UriInterface $url, ResponseInterface $response, ?UriInterface $foundOnUrl = null)
    {

        $response = $this->client->get($url);
        $content = $response->getBody()->getContents();
        $crawler = new Crawler($content);

        $links = $crawler->filter('a')->each(function ($node) {
            $href = $node->attr('href');
            $rel = $node->attr('rel');
            $title = $node->attr('title');
            $text = $node->text();
            return compact('href', 'title', 'text', 'rel');
        });

        dd($links);

        // $content = $response->getBody()->getContents();
        // $crawler = new Crawler($content);
        // dd($crawler);

        // $data = $crawler->filter('li.type-product')
        //     ->each(function (Crawler $node, $i) {
        //         return $array = [
        //             'date' => now(),
        //             // 'title' => $this->hasContent($node->filter('.woocommerce-loop-product__title')) != false ? $node->filter('.woocommerce-loop-product__title')->text() : '',
        //             // 'code' => arabic_e2w($this->hasContent($node->filter('div.add-to-cart-wrap a')) != false ? $node->filter('div.add-to-cart-wrap a')->eq(0)->attr('data-product_sku') : ''),
        //             // 'price' => preg_replace('/[^0-9]/', '', $this->hasContent($node->filter('.woocommerce-Price-amount')) != false ? $node->filter('.woocommerce-Price-amount')->text() : ''),
        //             // 'link' => $this->hasContent($node->filter('div.product-image-area a')) != false ? $node->filter('div.product-image-area a')->eq(0)->attr('href') : '',
        //         ];

        //     }
        //     );

        // $path = $url->getPath();
        // $doc = new DOMDocument();
        // @$doc->loadHTML($response->getBody());
        // // $title = $doc->getElementsByTagName("title")[0]->nodeValue;

        // $this->pages[] = [
        //     'path' => $path,
        //     // 'title' => $title,
        // ];

        // dd($doc);
        // dd($this->pages);

        dd($data);
        exit;
    }

    /**
     * Called when the crawler had a problem crawling the given url.
     *
     * @param \Psr\Http\Message\UriInterface $url
     * @param \GuzzleHttp\Exception\RequestException $requestException
     * @param \Psr\Http\Message\UriInterface|null $foundOnUrl
     */
    public function crawlFailed(UriInterface $url, RequestException $requestException, ?UriInterface $foundOnUrl = null)
    {
        echo 'failed';
    }

    public function finishedCrawling()
    {
        echo 'crawled ' . count($this->pages) . ' urls' . PHP_EOL;
        foreach ($this->pages as $page) {
            echo sprintf("Url  path: %s Page title: %s%s", $page['path'], $page['title'], PHP_EOL);
        }
    }
    private function hasContent($node)
    {
        return $node->count() > 0 ? true : false;
    }
    /**
     * Get node values
     * @filter function required the identifires, which we want to filter from the content.
     */

}