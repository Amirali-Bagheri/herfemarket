<?php

namespace Modules\Seo\Exceptions;

use RuntimeException;

class InvalidUrlException extends RuntimeException
{
}
