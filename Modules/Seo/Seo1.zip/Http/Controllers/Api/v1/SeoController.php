<?php

namespace Modules\Seo\Http\Controllers\Api\v1;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\TransferStats;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;
use Symfony\Component\DomCrawler\Crawler;

// use Goutte\Client;
// use Modules\Seo\Traits\SEO;

class SeoController extends Controller
{
    // use SEO;

    public function siteinfo($domain)
    {

        try {

            $response = $this->client->get(
                $domain,
                [
                    'on_stats' => function (TransferStats $stats) {
                        $this->loadtime = $stats->getTransferTime();
                    },

                    'headers' => [
                        'User-Agent' => 'Vandad Soft Seo Analyzer',
                    ],
                    'verify' => true,
                ]
            );

            $content = $response->getBody()->getContents();

            $document = new Crawler($content);

            $_this = $this;

            $title = $document->filter('head')->filter('title')->text();

            // dd($document->filter('//meta[@name="description"]')->attr('content'));

            $lang = $document->filter('html')->attr('lang');

            $h1 = $document->filter('h1')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });
            $h2 = $document->filter('h2')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });
            $h3 = $document->filter('h3')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });
            $h4 = $document->filter('h4')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });
            $h5 = $document->filter('h5')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });
            $h6 = $document->filter('h6')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });
            $p = $document->filter('p')->each(function (Crawler $node, $i) use ($_this) {
                return $node->text();
            });

            if ($this->url_exists($domain . '/sitemap.xml') or $this->url_exists($domain . '/sitemap')) {
                $sitemap = true;
            } else {
                $sitemap = false;
            }

            if ($this->url_exists($domain . '/robots.txt')) {
                $robots = true;
            } else {
                $robots = false;
            }

            return $this->virus_total($domain);

            $meta_link = $document->filter('link')->each(function ($node) {
                $href = $node->attr('href');
                $rel = $node->attr('rel');
                $title = $node->attr('title');
                $text = $node->text();
                return compact('href', 'title', 'text', 'rel');
            });
            $scripts = $document->filter('script')->each(function ($node) {
                if (!$node->text()) {
                    $src = $node->attr('src');
                    $type = $node->attr('type');
                    $defer = $node->attr('defer') ? true : false;
                    $async = $node->attr('async') ? true : false;
                    return compact('src', 'defer', 'async', 'text', 'type');
                }
            });

            $links = $document->filter('a')->each(function ($node) {
                $href = $node->attr('href');
                $rel = $node->attr('rel');
                $title = $node->attr('title');
                $text = $node->text();
                return compact('href', 'title', 'text', 'rel');
            });

            $images = $document->filter('img')->each(function ($node) use ($domain) {

                $src = $this->fixUrl($node->attr('src'), $domain);
                $alt = $node->attr('alt');
                $title = $node->attr('title');
                $status = $this->url_exists($src) ? true : false;

                return compact('src', 'alt', 'title', 'status');
            });

            //Full page result
            $usableSource = $content;
            $usableText = $this->getTextContent($usableSource);

            $htmlTxtRatio = 0;
            if (strlen($usableSource) > 0) {
                $htmlTxtRatio = strlen($usableText) / strlen($usableSource) * 100;
            }

            $fullPageResult = [

                // 'images'           => $this->doImageResult($document),
            ];

            $result = [
                'domain' => $domain,
                // 'canonical'   => $canonical,
                // 'baseUrl'     => $baseUrl,
                // 'domainUrl'   => $domainUrl,
                // 'domainname'  => $domainname,
                'links' => $links,
                'images' => $images,
                'meta_link' => $meta_link,
                'scripts' => $scripts,
                'title' => $title,
                // 'description' => $description,
                'language' => $lang,
                'h1' => $h1,
                'h2' => $h2,
                'h3' => $h3,
                'h4' => $h4,
                'h5' => $h5,
                'h6' => $h6,
                'sitemap' => $sitemap,
                'robots' => $robots,
                'loadtime' => $this->loadtime,
                'codeToTxtRatio' => [
                    'total_length' => strlen($usableSource),
                    'text_length' => strlen($usableText),
                    'ratio' => $htmlTxtRatio,
                ],
                'keywords' => $this->findKeywords($usableText),
                'longTailKeywords' => $this->getLongTailKeywords($usableText),
                'word_count' => $this->countWords($usableText),
                // 'full_page'   => $fullPageResult,
                // 'main_text'   => $mainTxtResult,
            ];

            return $result;

            // $bodyNode = $document->filter('body');

            // return  $body = $document->filter('body')->each(function (Crawler $node, $i) use ($_this) {
            //     return $node->text();
            // });

            // $nodes = $this->loadChilds($bodyNode);
            // foreach ($qry as $child) {
            //     if (!isset($node->tagName)) {
            //         continue;
            //     }
            //     if (in_array($child->tagName, ['svg', 'script'])) {
            //         continue;
            //     }

            //     if ($parentTagName === $child->parentNode->tagName && $parentToken === md5($child->parentNode->outerHTML)) {
            //         $loadedChilds = $this->loadChilds($child);
            //         $childs[md5($child->outerHTML)] = [
            //             'node'   => $child,
            //             'childs' => $loadedChilds,
            //         ];
            //     }
            // }

            // return $nodes;
        } catch (Exception $e) {
            return $e->getMessage();
        }

        // return $response->status();
        // return  $response->ok();

        // $headers =  $response->headers();

        // $client = new Client();

        // $document = $client->request('GET', $domain);
        // dd($document);

        // return file_get_contents($domain);

    }

    public function AlexaTopGlobalSites()
    {
        $client = new Client();
        $crawler = $client->request('GET', 'https://www.alexa.com/topsites');

        $table = $crawler->filter('div[class="td DescriptionCell"]')->filter('a[href]')->each(function ($node) {
            return $node->text();
        });
        return response()->json($table);
    }

    public function AlexaTopIranSites()
    {
        $client = new Client();
        $crawler = $client->request('GET', 'https://www.alexa.com/topsites/countries/IR');

        $table = $crawler->filter('div[class="td DescriptionCell"]')->filter('a[href]')->each(function ($node) {
            return $node->text();
        });
        return response()->json($table);
    }

    public function alexaRank($site)
    {
        $alexaData = simplexml_load_file("http://data.alexa.com/data?cli=10&url=" . $site);

        return response()->json([
            'global' => json_decode(isset($alexaData->SD->POPULARITY) ? $alexaData->SD->POPULARITY->attributes()->TEXT : 0),
            'country' => preg_replace('/[\x00-\x1F\x80-\xFF]/', '', isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes()->NAME : ''),
            'countryCode' => preg_replace('/[\x00-\x1F\x80-\xFF]/', '', isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes()->CODE : ''),
            'countryRank' => json_decode(isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes()->RANK : 0),
            'reach' => json_decode(isset($alexaData->SD->COUNTRY) ? $alexaData->SD->REACH->attributes()->RANK : 0),
            'rankGraph' => "http://traffic.alexa.com/graph?y=t&u=" . $site,
            'searchPercentGraph' => "http://traffic.alexa.com/graph?y=q&u=" . $site,
        ]);
    }

    public function siteSpeed($site)
    {
        // $content = $this->getHeadlessReponse($url);
        // $this->crawler->addContent($this->getHeadlessReponse($url));

        // $start_request = time();
        // $client = new Client();
        // $response = $client->request('GET', 'http://' . $site);
        // return $response->getStatus();
        // $end_request = time();

        // $time_taken = $end_request - $start_request;
    }

    public function msn_backlinks($domain)
    {
        // Use: Add following url parameters:
// link: The url you want to get the backlinnks from (required)
// siteFilter: The site your backlinks should come from (eg. twitter.com) (optional)
       return $response = Http::get("https://www.googleapis.com/customsearch/v1?key=AIzaSyDR2pX2yAgxtLqSIM6LJ5ZuEgWY0XK0OVQ&cx=007550170536913021735:ccsnjzddu5u&q=link:" . $domain)->json();

//        $link = $_GET["link"];
//        $siteFilter = $_GET["site"];
        $jsonObject = getJsonObject($link, $siteFilter);

// echo "Number of backlinks: ".$jsonObject['responseData']['cursor']['resultCount'];
    }

    public function googlePageRank($domain)
    {
        $response = Http::get("https://www.googleapis.com/customsearch/v1?key=AIzaSyDR2pX2yAgxtLqSIM6LJ5ZuEgWY0XK0OVQ&cx=007550170536913021735:ccsnjzddu5u&q=site:" . $domain)->json();

        return $response['items'];

    }
}
