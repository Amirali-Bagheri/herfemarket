<?php

namespace Modules\Seo\Http\Controllers\Admin;

use Exception;
use GuzzleHttp\Client;
use GuzzleHttp\Subscriber\Cache\CacheSubscriber;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;
use Symfony\Component\DomCrawler\Crawler;

class SeoController extends Controller
{
    private $client;


    public function __construct()
    {
        $this->client = new Client([
            'timeout' => 20,
            'verify' => false
        ]);
    }


    public function index()
    {
        return view('seo::admin.index');
    }

    public function google_pages(Request $request)
    {
        if ($request->has('domain')) {
            $domain = $request->domain;
        } else {
            $domain = env('APP_DOMAIN');

        }

        $response = Http::get("https://www.googleapis.com/customsearch/v1?key=AIzaSyDR2pX2yAgxtLqSIM6LJ5ZuEgWY0XK0OVQ&cx=007550170536913021735:ccsnjzddu5u&q=site:" . $domain)->json();

        $pages = collect($response['items'])->paginate(30);

        return view('seo::admin.google_pages', compact('pages'));
    }

    public function google_serp(Request $request)
    {
        $keyword = null;
        if ($request->has('domain')) {
            $domain = $request->domain;
        } else {
            $domain = env('APP_DOMAIN');
        }

        if ($request->isMethod('get')) {
            return view('seo::admin.google_serp', compact('domain', 'keyword'));
        } elseif ($request->isMethod('post')) {
            $request->validate([
                'domain' => 'required',
                'keyword' => 'required'
            ]);

            $keyword = $request->keyword;
            $serp = Http::withHeaders([
                'x-rapidapi-host' => 'google-search3.p.rapidapi.com',
                'x-rapidapi-key' => '0fa6f3cfe7mshd652864d39a573ap1cf60ejsn4a778b3c92aa',
                'content-type' => 'application/json',
                'accept' => 'application/json'
            ])->withBody(
                '{ "query": "q=' . $keyword . '", "website": "' . $domain . '"}', 'application/json'
            )->post('https://google-search3.p.rapidapi.com/api/v1/serp/')->json();

            return view('seo::admin.google_serp', compact('serp', 'domain', 'keyword'));
        }


    }

    public function backlinks(Request $request)
    {
        if ($request->has('domain')) {
            $domain = $request->domain;
        } else {
            $domain = env('APP_DOMAIN');

        }
        return $response = Http::withHeaders([
            'x-rapidapi-host' => 'google-search3.p.rapidapi.com',
            'x-rapidapi-key' => '0fa6f3cfe7mshd652864d39a573ap1cf60ejsn4a778b3c92aa'
        ])->get('https://google-search3.p.rapidapi.com/api/v1/search/q=link:' . $domain . '&num=500')->json();

        $response = Http::get("https://www.googleapis.com/customsearch/v1?key=AIzaSyDR2pX2yAgxtLqSIM6LJ5ZuEgWY0XK0OVQ&cx=007550170536913021735:ccsnjzddu5u&q=link:" . $domain)->json();

        $backlinks = collect($response['items'])->paginate(30);

        return view('seo::admin.google_backlinks', compact('backlinks'));
    }

    public function alexa(Request $request)
    {
        if ($request->has('domain')) {
            $domain = $request->domain;
        } else {
            $domain = env('APP_DOMAIN');
        }
        try {
            $response = $this->client->get("https://www.alexa.com/minisiteinfo/" . $domain . "?offset=5&version=alxg_20100607");
            $alexaData = simplexml_load_file("http://data.alexa.com/data?cli=10&url=" . $domain);

            $content = $response->getBody()->getContents();
            $crawler = new Crawler($content);

            $alexa = [
                'domain' => $domain,
                'global' => json_decode(isset($alexaData->SD->POPULARITY) ? $alexaData->SD->POPULARITY->attributes()->TEXT : 0),
                'country' => preg_replace('/[\x00-\x1F\x80-\xFF]/', '', isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes()->NAME : ''),
                'countryCode' => preg_replace('/[\x00-\x1F\x80-\xFF]/', '', isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes()->CODE : ''),
                'countryRank' => json_decode(isset($alexaData->SD->COUNTRY) ? $alexaData->SD->COUNTRY->attributes()->RANK : 0),
                'reach' => json_decode(isset($alexaData->SD->COUNTRY) ? $alexaData->SD->REACH->attributes()->RANK : 0),
                'backlinks' => json_decode($crawler->filter('table.chrome')->filter('.start .data a')->text()),
                'rankGraph' => "http://traffic.alexa.com/graph?y=t&u=" . $domain,
                'searchPercentGraph' => "http://traffic.alexa.com/graph?y=q&u=" . $domain,
            ];
            return view('seo::admin.alexa', compact('alexa', 'domain'));

        } catch (Exception $e) {
            echo $e->getMessage();
        }


    }

    public function alexaTopSites()
    {
        try {
            $global_response = $this->client->get("https://www.alexa.com/topsites");
            $global_content = $global_response->getBody()->getContents();
            $global_crawler = new Crawler($global_content);
            $global = $global_crawler->filter('div[class="td DescriptionCell"]')->filter('a[href]')->each(function ($node) {
                return $node->text();
            });

            $country_response = $this->client->get("https://www.alexa.com/topsites/countries/IR");
            $country_content = $country_response->getBody()->getContents();
            $country_crawler = new Crawler($country_content);
            $country = $country_crawler->filter('div[class="td DescriptionCell"]')->filter('a[href]')->each(function ($node) {
                return $node->text();
            });


            return view('seo::admin.alexa_top_sites', compact('global', 'country'));

        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    private function hasContent($node)
    {
        return $node->count() > 0 ? true : false;
    }

    private function getKeywordSuggestionsFromGoogle(Request $request, $keyword)
    {
        $keywords = array();
        $data = file_get_contents('http://suggestqueries.google.com/complete/search?output=firefox&client=firefox&hl=en-US&q=' . urlencode($keyword));
        if (($data = json_decode($data, true)) !== null) {
            $keywords = $data[1];
        }

        return $keywords;


        var_dump(getKeywordSuggestionsFromGoogle('money'));
    }

}
