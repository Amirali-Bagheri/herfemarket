<?php

namespace Modules\Seo\Entities;

use Spatie\Crawler\CrawlAllUrls;

class CheckAllLinks extends CrawlAllUrls
{

}
