<?php

namespace Modules\Seo\Contracts\Packages\Entities;

use Modules\Seo\Contracts\Packages\PackageInterface;

interface JsonLdPackageInterface extends PackageInterface
{

}
