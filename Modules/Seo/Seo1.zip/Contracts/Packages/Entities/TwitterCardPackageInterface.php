<?php

namespace Modules\Seo\Contracts\Packages\Entities;

use Modules\Seo\Contracts\Packages\PackageInterface;

interface TwitterCardPackageInterface extends PackageInterface
{

}